Pokedex.Models.Toy = Backbone.Model.extend({
  urlRoot: "/toys"

});
