#require_relative "board"

class Tile
  NEIGHBORS = [
    [-1,-1],
    [-1, 0],
    [-1, 1],
    [0, -1],
    [0, 1],
    [1, -1],
    [1, 0],
    [1,1]
  ]

  attr_reader :bombed, :flagged, :revealed, :position, :board

  def initialize(bombed, position, board)
    @board = board
    @position = position
    @bombed = bombed
    @flagged = false
    @revealed = false
  end

  def reveal
    @revealed = true
  end

  def change_flag
    @flagged = !@flagged
  end

  def inspect
    "position: #{@position}, bombed: #{@bombed}, flagged: #{@flagged}, revealed: #{@revealed}"
  end

  def neighbors
    valid_neighbors = []
    NEIGHBORS.each do |nbr|
      neighbor_pos = [position[0] + nbr[0], position[1] + nbr[1]]
      if in_board?(neighbor_pos)
        valid_neighbors << board[[neighbor_pos[0],neighbor_pos[1]]]
      end
    end

    valid_neighbors
  end

  def neighbors_bomb_count
    bombed ? count = 1 : count = 0
    neighbors.each do |neighbor|
      count += 1 if neighbor.bombed
    end

    count
  end

  def in_board?(position)
    position[0].between?(0,board.rows - 1) && position[1].between?(0,board.cols - 1)
  end

  def to_s
    if flagged
      "F"
    elsif revealed
      num = neighbors_bomb_count
      if bombed
        "B"
      elsif num == 0
        "_"
      else
        "#{num}"
      end
    else
      "*"
    end
  end
end
