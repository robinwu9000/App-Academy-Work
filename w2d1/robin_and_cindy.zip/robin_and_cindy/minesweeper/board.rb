require "Set"
require_relative "tile"
require "colorize"

class Board
    attr_accessor :rows, :cols, :num_bombs

    def initialize(rows, cols, num_bombs)
      @rows = rows
      @cols = cols
      @num_bombs = num_bombs
      @grid = Array.new(rows) {Array.new(cols)}
      populate
    end

    def[](pos)
      x,y = pos[0], pos[1]
      @grid[x][y]
    end

    def []=(pos, value)
      x,y = pos[0], pos[1]
      @grid[x][y] = value
    end

    def populate
      bombs = bomb_positions
      (0...rows).each do |row|
        (0...cols).each do |col|
          if bombs.include?([row, col])
            self[[row, col]] = Tile.new(true, [row,col], self)
          else
            self[[row, col]] = Tile.new(false, [row,col], self)
          end
        end
      end
    end

    def reveal(tile)
      queue = []
      queue << tile
      until queue.empty?
        current = queue.shift
        current.reveal unless current.flagged == true
        available = current.neighbors if current.neighbors_bomb_count == 0
        if !available.nil?
          available.each do |neighbor|
            queue << neighbor if !neighbor.revealed
          end
        end
      end
    end

    def game_lost?
      @grid.flatten.any? {|el| el.bombed && el.revealed}
    end

    def game_won?
      count_revealed = 0
      count_flagged = 0
      (0...rows).each do |row|
        (0...cols).each do |col|
          count_revealed += 1 if self[[row,col]].revealed
          count_flagged += 1 if self[[row,col]].flagged
        end
      end
      (count_revealed + count_flagged) == (rows * cols - num_bombs)
        && count_flagged <= num_bombs
    end

    def flag(tile)
      tile.change_flag
    end

    def reveal_all
      (0...rows).each do |row|
        (0...cols).each do |col|
          self[[row,col]].reveal
        end
      end
    end

    def bomb_positions
      positions = Set.new
      until positions.length == num_bombs
        positions << [rand(rows), rand(cols)]
      end
      positions
    end

    def print_board(cursor_position)
      puts "  " + (0...cols).to_a.join(" ")
      (0...rows).each do |row|
        print row.to_s + " "
        (0...cols).each do |col|
          if [row, col] == cursor_position
            print self[[row, col]].to_s.colorize(:green) + " "
          else
            print self[[row, col]].to_s + " "
          end
        end
        puts
      end
    end
end
