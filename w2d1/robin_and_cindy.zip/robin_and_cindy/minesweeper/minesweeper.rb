require_relative "board"
require "yaml"
require_relative "keypress"

class Minesweeper
  attr_accessor :board

  def initialize(rows, cols, num_bombs = 10)
    @board = Board.new(rows, cols, num_bombs)
    @cursor_position = [0,0]
  end

  def play
    until board.game_lost? || board.game_won?
      system("clear")
      board.print_board(@cursor_position)
      play_turn
    end

    board.reveal_all
    board.print_board(@cursor_position)
    print_message
  end

  def play_turn
    # p position
    case get_action
    when "\e[A"
      @cursor_position[0] -= 1 unless @cursor_position[0] == 0
    when "\e[B"
      @cursor_position[0] += 1 unless @cursor_position[0] == board.rows - 1
    when "\e[C"
      @cursor_position[1] += 1 unless @cursor_position[1] == board.cols - 1
    when "\e[D"
      @cursor_position[1] -= 1 unless @cursor_position[1] == 0
    when "e"
      abort("You left the game")
    when "s"
      save_game
    when "l"
      load_game
    when "r"
      board.reveal(board[@cursor_position])
      board.print_board(@cursor_position)
    when "f"
      board.flag(board[@cursor_position])
      board.print_board(@cursor_position)
    else
      puts "Cannot understand action"
    end
  end

  def save_game
    File.write("./minesweeper_save.yml", board.to_yaml)
  end

  def load_game
    @board = YAML.load_file("./minesweeper_save.yml")
  end

  def valid_position?(position)
    position[0].between?(0,board.rows - 1) && position[1].between?(0,board.cols - 1)
  end

  def print_message
    puts board.game_lost? ? "You lost" : "You win"
  end

  def get_position
    puts "Please enter a position:"
    pos = gets.chomp.split(",").map! {|i| i.to_i}
    until valid_position?(pos)
      puts "Your entry was invalid, try again"
      pos = gets.chomp.split(",").map! {|i| i.to_i}
    end
    pos
  end

  def get_action
    show_single_key
    # puts "What do you want to do? (f)lag/unflag, (r)eveal, (s)ave, (l)oad, (e)xit"
    # action = gets.chomp.downcase
    # until ["f", "r", "s", "l", "e"].include?(action)
    #   puts "Invalid action, try again"
    #   action = gets.chomp.downcase
    # end
    # action
  end
end

game = Minesweeper.new(9,9,10)
game.play
