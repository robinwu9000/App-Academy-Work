# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
NewsReader::Application.config.secret_token = '97c3e54c45c622259dedda53895ed206c10a0e25e71f6c8e631cbf996185b108b7ddcc51bcbb10820ecc496d1c7204d50814ec3878d4bfebb7db0d0f67b37107'
