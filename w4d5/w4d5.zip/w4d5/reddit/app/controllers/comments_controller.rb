class CommentsController < ApplicationController
  before_action :require_login

  def create
    @comment = Comment.new(comment_params)
    @comment.post_id = params[:comment][:post_id]
    @comment.parent_comment_id = params[:comment][:parent_comment_id]
    @comment.author = current_user
    if @comment.save
      redirect_to @comment.post
    else
      flash.now[:errors] = @comment.errors.full_messages
      render :new
    end
  end

  def new
    render :new
  end

  def show
    @comment = Comment.find_by_id(params[:id])
    render :show
  end

  def comment_params
    params.require(:comment).permit(:content)
  end
end
