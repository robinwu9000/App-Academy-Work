class PostsController < ApplicationController
  before_action :require_author, only: [:edit, :update]
  before_action :require_author_or_moderator, only: :destroy

  def show
    @post = Post.find_by_id(params[:id])
    render :show
  end

  def new
    @post = Post.new
    @post.sub_ids = params[:sub_id]
    render :new
  end

  def create
    @post = Post.new(post_params)
    @post.sub_ids = params[:post][:subs_id]
    @post.author = current_user
    if @post.save
      redirect_to post_url(@post)
    else
      flash.now[:errors] = @post.errors.full_messages
      render :new
    end
  end

  def edit
    @post = Post.find_by_id(params[:id])
    render :edit
  end

  def update
    @post = Post.find_by_id(params[:id])
    @post.sub_ids = params[:post][:subs_id]

    if @post.update_attributes(post_params)
      redirect_to post_url(@post)
    else
      flash.now[:errors] = @post.errors.full_messages
      render :edit
    end
  end

  def destroy
    @post = Post.find_by_id(params[:id])
    if @post.destroy
      redirect_to @post.sub
    else
      flash[:errors] = ["Delete unsuccessful"]
      redirect_to @post.sub
    end
  end

  def require_author
    @post = Post.find_by_id(params[:id])
    unless current_user == @post.author
      flash[:errors] = ["You don't have edit authorization"]
      redirect_to @post
    end
  end

  def require_author_or_moderator
    @post = Post.find_by_id(params[:id])
    unless current_user == @post.author || current_user == @post.sub.moderator
      flash[:errors] = ["You can't delete this post"]
      redirect_to @post
    end
  end

  def post_params
    params.require(:post).permit(:title, :url, :content)
  end
end
