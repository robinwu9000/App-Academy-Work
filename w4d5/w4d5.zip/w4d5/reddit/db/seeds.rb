20.times do
  User.create!(
    username: Faker::Internet.user_name,
    password: Faker::Internet.password
  )
end

user = User.create!(username: 'user', password: 'password')
Sub.create!(title: 'Default sub',
            description: 'This is a default sub',
            moderator: user)

User.all.each do |user|
  (rand(2)).times do
    Sub.create!(
      title: Faker::Lorem.word,
      description: Faker::Lorem.paragraph(rand(5)+ 1),
      moderator: user
    )
  end

  (rand(3)).times do
    if rand > 0.5
      url = Faker::Internet.url
      content = nil
    else
      url = nil
      content = Faker::Lorem.paragraph(rand(5)+1)
    end
    Post.create!(
      author: user,
      title: Faker::Lorem.sentence(rand(5)+1),
      content: content,
      url: url,
      sub: Sub.all.sample
    )
  end
end
