Rails.application.routes.draw do
  get 'signup', to: 'users#new'
  post 'signup', to: 'users#create'

  get 'login', to: 'sessions#new'
  post 'login', to: 'sessions#create'

  resources :subs, except: :destroy do
    resources :posts, only: [:new]
  end

  resources :posts, except: [:new] do
    resources :comments, only: :new
  end

  resources :comments, only: [:create, :show]

  root to: 'subs#index'
end
