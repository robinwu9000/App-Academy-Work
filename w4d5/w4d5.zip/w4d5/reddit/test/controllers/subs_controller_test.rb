require 'test_helper'

class SubsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
