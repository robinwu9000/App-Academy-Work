require 'rails_helper'

RSpec.describe ToysController, type: :controller do

end
