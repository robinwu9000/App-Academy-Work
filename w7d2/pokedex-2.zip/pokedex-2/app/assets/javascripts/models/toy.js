Pokedex.Models.Toy = Backbone.Model.extend({
});
