Pokedex.Collections.Toys = Backbone.Collection.extend({
  model: Pokedex.Models.Toy
});
