# REVERSI JS STYLE

To play the game, run

    npm start

To run the tests, run

    npm test
