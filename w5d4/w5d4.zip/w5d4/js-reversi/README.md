# w5d4: [JS Reversi][description]

[description]: https://github.com/appacademy/js-curriculum/blob/master/projects/w5d4-reversi.md
