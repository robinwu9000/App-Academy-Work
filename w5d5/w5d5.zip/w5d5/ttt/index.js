module.exports = {
  Board: require("./board.js"),
  Game: require("./game.js")
};
